Online Voting App is designed to automate the voting system where multiple parties are added and process.
